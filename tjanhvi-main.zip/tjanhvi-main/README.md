![](https://raw.githubusercontent.com/tjanhvi/tjanhvi/master/Profile1.gif)
<br>
<p align="center">
<img src="https://i.pinimg.com/originals/00/4b/17/004b173f6e3d6843df10114e087f30a8.gif" width="50" height="50" />
</p>

![](https://komarev.com/ghpvc/?username=tjanhvi&color=blue)•
<img src="https://badges.pufler.dev/repos/tjanhvi" />•
<img src="https://badges.pufler.dev/commits/monthly/tjanhvi" />•
<img alt="𝙶𝚒𝚝𝙷𝚞𝚋 𝚏𝚘𝚕𝚕𝚘𝚠𝚎𝚛𝚜" src="https://img.shields.io/github/followers/tjanhvi?label=Followers&style=social"> • 
<img src="https://img.shields.io/github/stars/tjanhvi?label=Stars" alt="𝚃𝚘𝚝𝚊𝚕 𝚂𝚝𝚊𝚛𝚜">

  
- 🔭 I’m currently working as contributor in a Open Soucre Contribution Program GWSOC'21
- 🔭  I was the contributior in a Open Soucre Contribution Program LGSMOC'21
- 🌱 I’m currently pursuing B.tech CSE
- 👯 I’m looking to collaborate on C++, Web Development and Python
- 🤔 I’m looking for help with Data Science
- 💬 Ask me about Python, C++, Web Development and related to tech
- 📫 How to reach me: [linkedin: @JanhviTiwari](https://www.linkedin.com/in/janhvi-tiwari-2837331b5/), [instagram: @tjanhvi560](https://www.instagram.com/tjanhvi560/), [facebook: @JanhviTiwari](https://www.facebook.com/janhvi.tiwari.7792)
- 📫 My Portfolio Website - (http://janhvi.epizy.com/)
- 😄 Pronouns: She/Her
- ⚡ Fun fact:Favourite --> Lucifer: The Morning Star / horror movies😂

<h2 align="center">⚛ Connect With Me ⚛</h2>
<p align="center">
  <a href="https://www.linkedin.com/in/janhvi-tiwari-2837331b5/" target="blank">
    <img align="center" src="https://cdn.jsdelivr.net/npm/simple-icons@3.0.1/icons/linkedin.svg" alt="https://www.linkedin.com/in/janhvi-tiwari-2837331b5/" height="30" width="40" />
  </a>
<a href="https:/https://www.facebook.com/janhvi.tiwari.773124/www.facebook.com/janhvi.tiwari.773124" target="blank">
  <img align="center" src="https://cdn.jsdelivr.net/npm/simple-icons@3.0.1/icons/facebook.svg" alt="https://www.facebook.com/janhvi.tiwari.773124" height="30" width="40" /></a>
<a href="https://www.codechef.com/users/janhvi_560" target="blank">
  <img align="center" src="https://cdn.jsdelivr.net/npm/simple-icons@3.1.0/icons/codechef.svg" alt="https://www.codechef.com/users/janhvi_560" height="30" width="40" />
</a>
<a href="https://www.hackerrank.com/tjanhvi560" target="blank">
  <img align="center" src="https://cdn.jsdelivr.net/npm/simple-icons@3.0.1/icons/hackerrank.svg" alt="https://www.hackerrank.com/tjanhvi560" height="30" width="40" />
</a>
<a href="https://auth.geeksforgeeks.org/user/tjanhvi560/" target="blank">
  <img align="center" src="https://cdn.jsdelivr.net/npm/simple-icons@3.0.1/icons/geeksforgeeks.svg" alt="https://auth.geeksforgeeks.org/user/tjanhvi560/" height="30" width="40" />
</a>
</p>
<br>

<h2 align="center">⚛ Languages and Tools ⚛</h2>

<p align="center"> 
 <a href="https://getbootstrap.com" target="_blank">
  <img src="https://raw.githubusercontent.com/devicons/devicon/master/icons/bootstrap/bootstrap-plain-wordmark.svg" alt="bootstrap" width="40" height="40"/> 
</a> 
<a href="https://www.cprogramming.com/" target="_blank"> 
  <img src="https://raw.githubusercontent.com/devicons/devicon/master/icons/c/c-original.svg" alt="c" width="40" height="40"/> 
</a>
<a href="https://www.w3schools.com/css/" target="_blank"> 
  <img src="https://raw.githubusercontent.com/devicons/devicon/master/icons/css3/css3-original-wordmark.svg" alt="css3" width="40" height="40"/> 
</a>
<a href="https://git-scm.com/" target="_blank">
  <img src="https://www.vectorlogo.zone/logos/git-scm/git-scm-icon.svg" alt="git" width="40" height="40"/>
</a> 
<a href="https://heroku.com" target="_blank"> 
  <img src="https://www.vectorlogo.zone/logos/heroku/heroku-icon.svg" alt="heroku" width="40" height="40"/>
</a>
<a href="https://www.w3.org/html/" target="_blank"> 
  <img src="https://raw.githubusercontent.com/devicons/devicon/master/icons/html5/html5-original-wordmark.svg" alt="html5" width="40" height="40"/> 
</a> 
<a href="https://developer.mozilla.org/en-US/docs/Web/JavaScript" target="_blank">
  <img src="https://raw.githubusercontent.com/devicons/devicon/master/icons/javascript/javascript-original.svg" alt="javascript" width="40" height="40"/>
</a>
<a href="https://opencv.org/" target="_blank">
  <img src="https://www.vectorlogo.zone/logos/opencv/opencv-icon.svg" alt="opencv" width="40" height="40"/> 
</a>
<a href="https://www.php.net" target="_blank">
  <img src="https://raw.githubusercontent.com/devicons/devicon/master/icons/php/php-original.svg" alt="php" width="40" height="40"/>
</a>
<a href="https://www.python.org" target="_blank">
  <img src="https://raw.githubusercontent.com/devicons/devicon/master/icons/python/python-original.svg" alt="python" width="40" height="40"/> 
</a>
<a href="https://www.w3schools.com/cpp/" target="_blank"> 
  <img src="https://raw.githubusercontent.com/devicons/devicon/master/icons/cplusplus/cplusplus-original.svg" alt="cplusplus" width="40" height="40"/>
</a> 
</p>

<br>

<h2 align="center">⚙️ GitHub Analytics ⚙️</h2>
<br>
<p align="center">
<a href="https://github.com/tjanhvi">
  <img height="180em" src="https://github-readme-stats-eight-theta.vercel.app/api?username=tjanhvi&show_icons=true&theme=algolia&include_all_commits=true&count_private=true"/> 
</a>
</p>

<p align = "center">
    <img height="180em" src="https://github-readme-stats-eight-theta.vercel.app/api/top-langs/?username=tjanhvi&layout=compact&langs_count=8&theme=algolia"/>
</p> 
 
<p align = "center">
<img width="50%" src="https://github-readme-streak-stats.herokuapp.com/?user=tjanhvi&show_icons=true&locale=en&layout=compact&theme=algolia&line_height=0" />
</p> 

![Janhvi's github activity graph](https://activity-graph.herokuapp.com/graph?username=tjanhvi&bg_color=000000&color=4cd8f0&line=2fc8ee&point=ffffff&area=true&hide_border=true)

<summary>Trophy: Github Profile Trophy</summary>
<br/>
<img src="https://github-profile-trophy.vercel.app/?username=tjanhvi&theme=monokai&row=1&no-frame=true&no-bg=true/">

![snake gif](https://github.com/tjanhvi/tjanhvi/blob/output/github-contribution-grid-snake.svg)

<!-- ![footer](https://raw.githubusercontent.com/tjanhvi/tjanhvi/main/footer.png) -->
